package com.ibs.simulator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
