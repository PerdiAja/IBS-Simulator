TEMPAT MODUL UNITY AS A LIBRARY

Folder ini sengaja belum berisi modul Gradle palsu.
Ekspor proyek Unity sebagai Android Library dari Unity Editor, lalu salin folder unityLibrary hasil ekspor ke lokasi ini.
Ikuti Docs/FLUTTER_UNITY_INTEGRATION.md di folder Unity.
Setelah modul asli tersedia, konfigurasi Gradle dan native Activity harus disesuaikan dengan versi Unity Editor yang digunakan.
