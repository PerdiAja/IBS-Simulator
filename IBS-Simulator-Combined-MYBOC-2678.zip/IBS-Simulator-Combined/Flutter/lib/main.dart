import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const IbsApp());

class IbsApp extends StatelessWidget {
  const IbsApp({super.key});

  @override
  Widget build(BuildContext context) {
    const orange = Color(0xFFFF7A18);
    return MaterialApp(
      title: 'IBS Simulator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: orange, brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF101216),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF101216), elevation: 0),
        cardTheme: CardThemeData(color: const Color(0xFF1B2028), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _tab = 0;
  final TextEditingController _serverController = TextEditingController(text: 'https://garzy-official-store.myboc.my.id:2678');
  String _serverStatus = 'Belum diperiksa';
  bool _checking = false;

  @override
  void dispose() {
    _serverController.dispose();
    super.dispose();
  }

  Future<void> _checkServer() async {
    final uri = Uri.tryParse('${_serverController.text.trim().replaceAll(RegExp(r'/+$'), '')}/health');
    if (uri == null || !uri.hasScheme || uri.host.isEmpty) {
      setState(() => _serverStatus = 'Alamat server tidak valid');
      return;
    }
    setState(() { _checking = true; _serverStatus = 'Menghubungkan...'; });
    try {
      final response = await http.get(uri).timeout(const Duration(seconds: 7));
      if (!mounted) return;
      setState(() => _serverStatus = response.statusCode == 200 ? 'Terhubung ke server IBS' : 'Server merespons: HTTP ${response.statusCode}');
    } catch (_) {
      if (!mounted) return;
      setState(() => _serverStatus = 'Tidak dapat terhubung. Periksa alamat dan jaringan.');
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [_home(), _garage(), _map(), _settings()];
    return Scaffold(
      appBar: AppBar(title: const Text('IBS SIMULATOR', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), actions: [IconButton(onPressed: _checkServer, icon: const Icon(Icons.cloud_sync))]),
      body: SafeArea(child: IndexedStack(index: _tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.directions_bus_filled), label: 'Garasi'),
          NavigationDestination(icon: Icon(Icons.map_outlined), label: 'Peta'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Pengaturan'),
        ],
      ),
    );
  }

  Widget _home() => ListView(padding: const EdgeInsets.all(18), children: [
    ClipRRect(borderRadius: BorderRadius.circular(22), child: Image.asset('assets/images/ibs_splash.png', height: 220, fit: BoxFit.cover)),
    const SizedBox(height: 18),
    const Text('JALANAN NUSANTARA MENUNGGU.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8),
    const Text('Bangun karier, kelola armada, dan jelajahi rute antarkota dalam dunia IBS Simulator.', style: TextStyle(color: Colors.white70, height: 1.45)),
    const SizedBox(height: 18),
    FilledButton.icon(onPressed: _showGameNotice, icon: const Icon(Icons.play_arrow_rounded), label: const Padding(padding: EdgeInsets.all(12), child: Text('MULAI BERMAIN'))),
    const SizedBox(height: 14),
    _statusCard(Icons.cloud_done_outlined, 'STATUS SERVER', _serverStatus),
    const SizedBox(height: 12),
    _quickCard(Icons.route, 'Karier Trayek', 'Pilih perjalanan AKDP dan AKAP', () => setState(() => _tab = 2)),
    _quickCard(Icons.directions_bus, 'Armada Bus', 'Lihat bus yang tersedia di garasi', () => setState(() => _tab = 1)),
  ]);

  Widget _garage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('GARASI', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8),
    const Text('Daftar kendaraan awal proyek. Spesifikasi dan model final akan ditambahkan bertahap.', style: TextStyle(color: Colors.white70)),
    const SizedBox(height: 14),
    _busCard('IBS AntarKota 12M', 'Big Coach • 2 axle • 45 kursi', '12500 kg • 900 Nm'),
    _busCard('IBS Medium 8M', 'Medium Bus • 3/4 • 28 kursi', '6200 kg • 520 Nm'),
    _busCard('IBS Double Deck Tour', 'Bus tingkat • Pariwisata', 'Model belum tersedia'),
  ]);

  Widget _map() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('PETA & TRAYEK', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
    const SizedBox(height: 12),
    _quickCard(Icons.route, 'Kutoarjo – Purworejo', 'Rute prototipe untuk pengujian awal', _showRouteNotice),
    _quickCard(Icons.terrain, 'Jalur Pegunungan', 'Wilayah ekspansi berikutnya', _showRouteNotice),
    _quickCard(Icons.toll, 'Jalan Tol Trans', 'Wilayah ekspansi berikutnya', _showRouteNotice),
  ]);

  Widget _settings() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('PENGATURAN', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
    const SizedBox(height: 12),
    const Text('KONEKSI SERVER', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFFF9A43))),
    const SizedBox(height: 8),
    TextField(controller: _serverController, keyboardType: TextInputType.url, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Alamat server', hintText: 'https://server-kamu.example')),
    const SizedBox(height: 10),
    FilledButton.icon(onPressed: _checking ? null : _checkServer, icon: _checking ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.wifi_tethering), label: const Text('UJI KONEKSI')),
    const SizedBox(height: 8),
    Text(_serverStatus, style: const TextStyle(color: Colors.white70)),
    const Divider(height: 30),
    _settingRow('Bahasa', 'Indonesia'),
    _settingRow('Grafik', 'Atur di dalam game Unity'),
    _settingRow('Kontrol', 'Atur di dalam game Unity'),
    _settingRow('Versi aplikasi', '0.1.0 • Starter'),
  ]);

  Widget _statusCard(IconData icon, String title, String value) => Card(child: ListTile(leading: Icon(icon, color: const Color(0xFFFF9A43)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(value)));
  Widget _quickCard(IconData icon, String title, String subtitle, VoidCallback action) => Card(child: ListTile(onTap: action, leading: Icon(icon, color: const Color(0xFFFF9A43)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right)));
  Widget _busCard(String title, String subtitle, String spec) => Card(child: ListTile(isThreeLine: true, leading: const CircleAvatar(backgroundColor: Color(0xFF34302B), child: Icon(Icons.directions_bus, color: Color(0xFFFF9A43))), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('$subtitle\n$spec')));
  Widget _settingRow(String title, String value) => ListTile(title: Text(title), subtitle: Text(value), trailing: const Icon(Icons.chevron_right));

  void _showGameNotice() => showDialog<void>(context: context, builder: (context) => AlertDialog(title: const Text('Modul game Unity'), content: const Text('Aplikasi Flutter dan proyek Unity sudah disediakan terpisah. Untuk menjalankan game dari aplikasi ini, ekspor Unity sebagai Unity as a Library lalu integrasikan modul Android-nya. Paket ini belum mengklaim integrasi tersebut sudah selesai.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('MENGERTI'))]));
  void _showRouteNotice() => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Data rute tersedia sebagai prototipe di proyek Unity.')));
}
