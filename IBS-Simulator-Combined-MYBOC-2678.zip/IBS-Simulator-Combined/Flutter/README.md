# IBS Simulator Flutter App

Aplikasi pendamping/launcher IBS Simulator (Flutter). Folder ini memiliki `pubspec.yaml`, source Dart, artwork splash, dan ikon launcher Android.

## Menjalankan

```bash
flutter create --platforms=android .   # lengkapi wrapper/platform boilerplate bila belum ada
flutter pub get
flutter run
```

## Build APK aplikasi Flutter

```bash
flutter build apk --release
```

## Ikon

Ikon Android tersedia di `android/app/src/main/res/mipmap-*`. Artwork sumber berada di `assets/images/ibs_game_icon_source.png`.

## Integrasi Unity

Proyek Unity ada di folder induk `Assets/`, `Packages/`, dan `ProjectSettings/`. Flutter app ini belum mengandung binary Unity as a Library. Untuk menjadikannya satu aplikasi yang membuka game secara native:

1. Buka proyek Unity dengan Unity 6 LTS.
2. Atur Player Settings > Android > Package Name menjadi `com.ibs.simulator`.
3. Ekspor/build Unity sebagai Android Library (Unity as a Library) mengikuti dokumentasi resmi versi Unity yang dipakai.
4. Integrasikan modul Unity Library dan dependensinya ke proyek Android Flutter, lalu buat channel/platform view untuk membuka dan menutup player Unity.
5. Uji lifecycle pause/resume, back button, orientasi, memory, dan build ARM64 pada perangkat fisik.

Jangan menganggap tombol Mulai Bermain sebagai integrasi Unity yang sudah selesai; tombol tersebut menjelaskan status integrasi secara transparan.
