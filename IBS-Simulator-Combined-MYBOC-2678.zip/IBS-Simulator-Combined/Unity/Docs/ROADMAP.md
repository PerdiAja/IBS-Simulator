# Six milestone roadmap

1. **M1 — Playable driving slice**: one bus primitive, one test road, keyboard/touch input, raycast suspension, air brakes, chase/cockpit camera. Acceptance: 10-minute drive without exceptions; stable save/load.
2. **M2 — Career loop**: route stops, passenger boarding state, timetable, trip payout, fuel station. Acceptance: complete a route and persist money/progress.
3. **M3 — World and traffic**: first compact region, traffic pooling, train crossing, weather/time. Acceptance: 30 FPS on 3 GB low preset; no unbounded traffic instantiation.
4. **M4 — Garage and mod data**: vehicle definitions, livery data format, safe package validation, 3 original bus prototypes. Acceptance: reject path traversal and oversized packages.
5. **M5 — Multiplayer**: Node identity/room directory, NGO dedicated server, replicated bus state, room browser. Acceptance: 8 clients in a test room with no invalid transform jumps.
6. **M6 — Content and release**: 12 original buses, 3 regions, localization, audio, accessibility, optimization and store compliance. Acceptance: device matrix, crash-free test sessions, performance budgets met.
