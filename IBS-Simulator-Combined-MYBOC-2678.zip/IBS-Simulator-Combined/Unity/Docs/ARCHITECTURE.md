# IBS Architecture

```text
Android / Windows Client
  Core (events, bootstrap)
   |-- Vehicle (Rigidbody, suspension, air brake, transmission)
   |-- Input -> Vehicle
   |-- Passenger -> NavMesh / Route
   |-- Traffic -> World
   |-- Weather -> World / WetSurface
   |-- Camera -> Vehicle
   |-- Economy -> Trip / Fuel / Save
   |-- Mods -> validated data packages
   |-- UI -> read-only presentation of module state
   |-- Save -> local profile / optional cloud API
   `-- Networking (NGO client) -> Unity Linux dedicated server
                                  |
                                  `-> Node.js API / SQLite
                                      (accounts, cloud save, room directory)
```

The current foundation uses a small static event hub for cross-module notifications. Production expansion should move high-frequency events to typed ScriptableObject channels and split each folder into its own asmdef. Unity dedicated server owns authoritative room simulation; Node.js handles identity, save data and room discovery.
