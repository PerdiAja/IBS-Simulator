# Integrasi Flutter + Unity as a Library (Android)

## Target arsitektur
Flutter menyediakan login/menu/garasi/pengaturan. Unity berjalan sebagai game 3D. Pemain memasang satu APK setelah modul Unity diekspor dan ditanam ke proyek Android Flutter. Server Node.js menjadi backend bersama.

## Status paket
Source Flutter, Unity, dan Server telah dikumpulkan dalam satu workspace. Modul Android Unity asli belum ada karena modul tersebut harus dihasilkan oleh Unity Editor versi yang dipakai. Folder `Flutter/android/unityLibrary/` hanya berisi instruksi placeholder, bukan library yang bisa di-compile.

## Alur integrasi
1. Buka proyek `Unity/` di Unity 6 dengan Android Build Support.
2. Ekspor/build sebagai Android Library / Unity as a Library.
3. Pindahkan modul `unityLibrary` hasil ekspor ke `Flutter/android/unityLibrary/`.
4. Tambahkan modul Gradle, dependency, manifest dan konfigurasi ABI yang dihasilkan Unity ke host Android Flutter. Jangan menebak versi Gradle/AGP; gunakan konfigurasi yang dihasilkan editor.
5. Tambahkan native bridge Android (Activity/Fragment/platform channel) untuk mengelola lifecycle UnityPlayer.
6. Sambungkan tombol Mulai Bermain Flutter ke native bridge.
7. Uji build release di perangkat nyata.

## Kriteria selesai
- Satu APK memasang Flutter host dan Unity game.
- Menu Flutter dapat membuka Unity dan kembali dengan aman.
- Pause/resume/back lifecycle tidak membuat crash.
- ARM64 build berhasil.
- Server endpoint dapat diakses dari perangkat.
