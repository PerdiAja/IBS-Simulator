# Baseline vehicle tuning

| Parameter | Starter value | Reason |
|---|---:|---|
| Bus mass | 12,500 kg | Empty large coach baseline |
| Passenger mass | 75 kg/person | Approximate seated passenger + belongings |
| Spring | 38,000 N/m | Initial long-travel coach suspension |
| Damper | 4,500 Ns/m | Controls rebound without excessive oscillation |
| Anti-roll | 8,000 N/m | Reduces body roll for prototype |
| Peak torque | 900 Nm @ 1,400 RPM | Mid-range diesel baseline |
| Ratios | 3.8, 2.4, 1.6, 1.1, .85, .68 | Six-speed prototype gearbox |
| Final drive | 4.1 | Coach launch / highway compromise |
| Air compressor | .8 bar/s | As requested in design brief |
| Air cut-out / cut-in | 12 / 9 bar | Reservoir pressure operating band |
| Fuel economy | 3–5 km/L target | Heavy coach simulation target |
