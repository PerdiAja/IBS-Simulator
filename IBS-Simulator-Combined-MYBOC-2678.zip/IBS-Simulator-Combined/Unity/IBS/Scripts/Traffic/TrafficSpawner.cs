using System.Collections.Generic;
using UnityEngine;
namespace IBS.Traffic
{
    /// <summary>Distance-aware pooled traffic spawner.</summary>
    public sealed class TrafficSpawner : MonoBehaviour
    {
        [SerializeField] private TrafficAI[] prefabs;
        [SerializeField] private Transform[] spawnPoints;
        [SerializeField] private Transform player;
        [SerializeField] private int poolSize = 24;
        [SerializeField] private float spawnRadius = 120f;
        private readonly Queue<TrafficAI> pool = new Queue<TrafficAI>();
        private void Start()
        {
            if (prefabs == null || prefabs.Length == 0) return;
            for (int i = 0; i < poolSize; i++)
            {
                TrafficAI item = Instantiate(prefabs[i % prefabs.Length], transform);
                item.gameObject.SetActive(false); pool.Enqueue(item);
            }
        }
        private void Update()
        {
            if (!player || spawnPoints == null || spawnPoints.Length == 0 || pool.Count == 0) return;
            Transform point = spawnPoints[Random.Range(0, spawnPoints.Length)];
            if (Vector3.Distance(player.position, point.position) > spawnRadius) return;
            TrafficAI item = pool.Dequeue();
            if (!item) return;
            item.transform.SetPositionAndRotation(point.position, point.rotation);
            item.gameObject.SetActive(true);
            pool.Enqueue(item);
        }
    }
}
