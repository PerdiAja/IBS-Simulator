using UnityEngine;
namespace IBS.Traffic
{
    /// <summary>Controls crossing barriers and warning lights while a train passes.</summary>
    public sealed class TrainCrossing : MonoBehaviour
    {
        [SerializeField] private Transform barrier;
        [SerializeField] private Light warningLight;
        [SerializeField] private AudioSource siren;
        [SerializeField] private float closeAngle = 88f;
        [SerializeField] private float movementSpeed = 45f;
        private bool trainApproaching;
        public void SetTrainApproaching(bool approaching) { trainApproaching = approaching; if (siren) { if (approaching) siren.Play(); else siren.Stop(); } }
        private void Update()
        {
            if (barrier) barrier.localRotation = Quaternion.RotateTowards(barrier.localRotation,
                Quaternion.Euler(0f, 0f, trainApproaching ? closeAngle : 0f), movementSpeed * Time.deltaTime);
            if (warningLight) warningLight.enabled = trainApproaching && Mathf.FloorToInt(Time.time * 3f) % 2 == 0;
        }
    }
}
