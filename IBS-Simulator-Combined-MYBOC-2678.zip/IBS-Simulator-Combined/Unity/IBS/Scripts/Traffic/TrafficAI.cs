using UnityEngine;
namespace IBS.Traffic
{
    /// <summary>Waypoint-following traffic vehicle with speed-limited movement.</summary>
    public sealed class TrafficAI : MonoBehaviour
    {
        [SerializeField] private Transform[] waypoints;
        [SerializeField] private float speedKph = 42f;
        [SerializeField] private float turnSpeed = 3f;
        private int index;
        private void Update()
        {
            if (waypoints == null || waypoints.Length == 0) return;
            Transform target = waypoints[index];
            Vector3 delta = target.position - transform.position;
            Vector3 flat = Vector3.ProjectOnPlane(delta, Vector3.up);
            if (flat.sqrMagnitude < 4f) index = (index + 1) % waypoints.Length;
            else
            {
                Quaternion look = Quaternion.LookRotation(flat.normalized, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, look, Time.deltaTime * turnSpeed);
                transform.position += transform.forward * (speedKph / 3.6f) * Time.deltaTime;
            }
        }
    }
}
