using UnityEngine;
using UnityEngine.UI;
using IBS.Vehicle;
namespace IBS.UI
{
    /// <summary>Updates core driving HUD labels from the active bus.</summary>
    public sealed class HUDController : MonoBehaviour
    {
        [SerializeField] private BusController bus;
        [SerializeField] private Text speedText, gearText, rpmText, airText;
        private void Update()
        {
            if (!bus) return;
            if (speedText) speedText.text = Mathf.RoundToInt(bus.SpeedKph) + " km/j";
            if (gearText) gearText.text = bus.Transmission.gear == 0 ? "R" : bus.Transmission.gear.ToString();
            if (rpmText) rpmText.text = Mathf.RoundToInt(bus.Rpm) + " RPM";
            if (airText) airText.text = bus.AirBrakes.pressureBar.ToString("0.0") + " bar";
        }
    }
}
