using UnityEngine;
namespace IBS.Settings
{
    /// <summary>Applies practical runtime quality presets and target frame rate.</summary>
    public sealed class GraphicsSettingsController : MonoBehaviour
    {
        public enum Preset { Low, Medium, High, Ultra }
        [SerializeField] private Preset preset = Preset.Medium;
        [SerializeField] private int targetFps = 60;
        private void Awake() { Apply(preset); }
        public void Apply(Preset value)
        {
            preset = value;
            QualitySettings.SetQualityLevel((int)value, true);
            Application.targetFrameRate = targetFps;
            QualitySettings.vSyncCount = 0;
            QualitySettings.shadowDistance = value == Preset.Low ? 25f : value == Preset.Medium ? 60f : value == Preset.High ? 100f : 160f;
            QualitySettings.antiAliasing = value == Preset.Low ? 0 : value == Preset.Medium ? 2 : 4;
        }
        public void SetTargetFps(int fps) { targetFps = Mathf.Clamp(fps, 30, 120); Application.targetFrameRate = targetFps; }
    }
}
