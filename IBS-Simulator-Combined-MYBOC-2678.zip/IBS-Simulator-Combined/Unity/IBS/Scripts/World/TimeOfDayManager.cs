using UnityEngine;
namespace IBS.World
{
    /// <summary>Advances a 24-hour clock and rotates the directional sun light.</summary>
    public sealed class TimeOfDayManager : MonoBehaviour
    {
        [SerializeField, Range(0f, 24f)] private float hour = 7f;
        [SerializeField] private float hoursPerRealSecond = 0.0041667f;
        [SerializeField] private Light sun;
        [SerializeField] private Gradient ambientColor;
        public float Hour => hour;
        private void Update()
        {
            hour = Mathf.Repeat(hour + Time.deltaTime * hoursPerRealSecond, 24f);
            float normalized = hour / 24f;
            if (sun) sun.transform.rotation = Quaternion.Euler((normalized * 360f) - 90f, 170f, 0f);
            if (ambientColor != null) RenderSettings.ambientLight = ambientColor.Evaluate(normalized);
        }
        public void SetHour(float value) => hour = Mathf.Repeat(value, 24f);
        public void SetTimeScale(float multiplier) => hoursPerRealSecond = Mathf.Max(0f, multiplier) / 3600f;
    }
}
