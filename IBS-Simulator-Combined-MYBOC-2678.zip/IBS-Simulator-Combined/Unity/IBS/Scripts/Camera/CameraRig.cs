using UnityEngine;
namespace IBS.Camera
{
    /// <summary>Vehicle camera modes with smoothed follow and orbit input.</summary>
    public sealed class CameraRig : MonoBehaviour
    {
        public enum Mode { Cockpit, Dashboard, Hood, Bumper, ChaseNear, ChaseFar, Orbit, TopDown, Cinematic, Drone }
        [SerializeField] private Transform target;
        [SerializeField] private Mode mode = Mode.ChaseNear;
        [SerializeField] private Vector3 chaseOffset = new Vector3(0f, 4.2f, -8f);
        [SerializeField] private float damping = 5f;
        [SerializeField, Range(40f, 100f)] private float fieldOfView = 65f;
        [SerializeField] private float orbitYaw, orbitPitch = 12f, zoom = 8f;
        private void LateUpdate()
        {
            if (!target) return;
            Vector3 offset = mode == Mode.TopDown ? new Vector3(0f, 22f, -1f) :
                mode == Mode.ChaseFar ? chaseOffset * 1.7f : mode == Mode.ChaseNear ? chaseOffset : new Vector3(0f, 2f, 0.2f);
            Quaternion rotation = mode == Mode.Orbit ?
                Quaternion.Euler(orbitPitch, orbitYaw, 0f) : target.rotation;
            Vector3 desired = target.position + rotation * offset;
            transform.position = Vector3.Lerp(transform.position, desired, Time.deltaTime * damping);
            Vector3 lookPoint = target.position + Vector3.up * 1.4f;
            transform.rotation = Quaternion.Slerp(transform.rotation,
                Quaternion.LookRotation(lookPoint - transform.position), Time.deltaTime * damping);
            if (GetComponent<UnityEngine.Camera>()) GetComponent<UnityEngine.Camera>().fieldOfView = fieldOfView;
        }
        public void SetMode(Mode value) => mode = value;
        public void Orbit(float yawDelta, float pitchDelta)
        {
            orbitYaw += yawDelta; orbitPitch = Mathf.Clamp(orbitPitch + pitchDelta, -10f, 75f); mode = Mode.Orbit;
        }
        public void Zoom(float delta) => zoom = Mathf.Clamp(zoom + delta, 2f, 20f);
    }
}
