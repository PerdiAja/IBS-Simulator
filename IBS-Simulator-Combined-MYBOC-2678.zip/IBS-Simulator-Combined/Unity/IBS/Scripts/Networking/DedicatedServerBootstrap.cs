using Unity.Netcode;
using UnityEngine;
namespace IBS.Networking
{
    /// <summary>Starts a headless NGO server when launched with the -ibs-server argument.</summary>
    public sealed class DedicatedServerBootstrap : MonoBehaviour
    {
        [SerializeField] private NetworkManager networkManager;
        private void Start()
        {
            if (System.Array.Exists(System.Environment.GetCommandLineArgs(), a => a == "-ibs-server"))
            {
                Application.runInBackground = true;
                if (networkManager && !networkManager.IsListening) networkManager.StartServer();
            }
        }
    }
}
