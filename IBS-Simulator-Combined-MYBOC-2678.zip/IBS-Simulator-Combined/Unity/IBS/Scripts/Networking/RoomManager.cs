using Unity.Netcode;
using UnityEngine;
namespace IBS.Networking
{
    /// <summary>Starts NGO host/client sessions; room codes are issued by the Node backend.</summary>
    public sealed class RoomManager : MonoBehaviour
    {
        [SerializeField] private NetworkManager networkManager;
        public bool StartHostRoom() => networkManager && networkManager.StartHost();
        public bool JoinRoom() => networkManager && networkManager.StartClient();
        public void LeaveRoom() { if (networkManager && networkManager.IsListening) networkManager.Shutdown(); }
    }
}
