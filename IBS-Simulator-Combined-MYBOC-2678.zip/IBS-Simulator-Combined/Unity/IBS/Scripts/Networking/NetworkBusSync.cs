using Unity.Netcode;
using UnityEngine;
namespace IBS.Networking
{
    /// <summary>Replicates server-authoritative bus state for nearby convoy clients.</summary>
    public sealed class NetworkBusSync : NetworkBehaviour
    {
        private NetworkVariable<Vector3> netPosition = new NetworkVariable<Vector3>(writePerm: NetworkVariableWritePermission.Server);
        private NetworkVariable<Quaternion> netRotation = new NetworkVariable<Quaternion>(writePerm: NetworkVariableWritePermission.Server);
        private NetworkVariable<float> netSpeed = new NetworkVariable<float>(writePerm: NetworkVariableWritePermission.Server);
        [SerializeField] private float interpolation = 12f;
        private Vector3 targetPosition;
        private Quaternion targetRotation;
        public override void OnNetworkSpawn()
        {
            targetPosition = transform.position; targetRotation = transform.rotation;
            netPosition.OnValueChanged += (_, value) => targetPosition = value;
            netRotation.OnValueChanged += (_, value) => targetRotation = value;
        }
        private void FixedUpdate()
        {
            if (!IsSpawned) return;
            if (IsServer)
            {
                netPosition.Value = transform.position;
                netRotation.Value = transform.rotation;
                netSpeed.Value = 0f;
            }
            else
            {
                transform.position = Vector3.Lerp(transform.position, targetPosition, Time.fixedDeltaTime * interpolation);
                transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.fixedDeltaTime * interpolation);
            }
        }
    }
}
