using UnityEngine;
using IBS.Vehicle;
namespace IBS.Audio
{
    /// <summary>Blends original engine loop layers by RPM and throttle.</summary>
    [RequireComponent(typeof(AudioSource))]
    public sealed class EngineAudio : MonoBehaviour
    {
        [SerializeField] private BusController bus;
        [SerializeField] private AudioSource idleLayer, lowLayer, highLayer;
        [SerializeField] private float pitchAtIdle = 0.85f, pitchAtRedline = 1.65f;
        private void Update()
        {
            if (!bus) return;
            float rpm = Mathf.InverseLerp(600f, 2600f, bus.Rpm);
            SetLayer(idleLayer, 1f - rpm);
            SetLayer(lowLayer, 1f - Mathf.Abs(rpm - 0.45f) * 2f);
            SetLayer(highLayer, rpm);
        }
        private void SetLayer(AudioSource source, float volume)
        {
            if (!source) return;
            source.volume = Mathf.Clamp01(volume);
            source.pitch = Mathf.Lerp(pitchAtIdle, pitchAtRedline, bus ? Mathf.InverseLerp(600f, 2600f, bus.Rpm) : 0f);
        }
    }
}
