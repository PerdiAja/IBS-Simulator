using UnityEngine;
using IBS.Core;

namespace IBS.Vehicle
{
    /// <summary>Rigidbody bus controller using raycast suspension and torque-based propulsion.</summary>
    [RequireComponent(typeof(Rigidbody))]
    public sealed class BusController : MonoBehaviour
    {
        [Header("Mass and engine")]
        [SerializeField] private float vehicleMass = 12500f;
        [SerializeField] private float peakTorqueNm = 900f;
        [SerializeField] private float peakTorqueRpm = 1400f;
        [SerializeField] private float maxRpm = 2600f;
        [SerializeField] private float idleRpm = 600f;
        [SerializeField] private float maxSpeedKph = 125f;
        [SerializeField] private Vector3 centerOfMassOffset = new Vector3(0f, -0.35f, 0.2f);
        [Header("Suspension")]
        [SerializeField] private WheelPoint[] wheels = new WheelPoint[4];
        [SerializeField] private float antiRollRate = 8000f;
        [Header("Handling")]
        [SerializeField] private float maxSteerAngle = 32f;
        [SerializeField] private float steeringAssistAtSpeed = 0.45f;
        [SerializeField] private float serviceBrakeForce = 42000f;
        [SerializeField] private float engineBrakeForce = 1800f;
        [SerializeField] private float aerodynamicDrag = 0.42f;
        [SerializeField] private float rollingResistance = 180f;

        public readonly TransmissionSystem Transmission = new TransmissionSystem();
        public readonly AirBrakeSystem AirBrakes = new AirBrakeSystem();
        public float Throttle { get; set; }
        public float Brake { get; set; }
        public float Steering { get; set; }
        public float Retarder { get; set; }
        public bool EngineRunning { get; private set; } = true;
        public float SpeedKph => body ? body.velocity.magnitude * 3.6f : 0f;
        public float Rpm { get; private set; } = 600f;
        public Rigidbody Body => body;
        private Rigidbody body;
        private float engineTemperature = 85f;

        private void Awake()
        {
            body = GetComponent<Rigidbody>();
            body.mass = vehicleMass;
            body.centerOfMass = centerOfMassOffset;
            body.interpolation = RigidbodyInterpolation.Interpolate;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        }

        private void FixedUpdate()
        {
            if (!EngineRunning || body == null) return;
            float dt = Time.fixedDeltaTime;
            ApplySuspension();
            float speed = SpeedKph;
            float brake = AirBrakes.Tick(Brake, dt);
            Transmission.Tick(Rpm, speed);
            float ratio = Mathf.Abs(Transmission.ShiftRatio);
            float torqueCurve = Mathf.Clamp01(1f - Mathf.Abs(Rpm - peakTorqueRpm) / (maxRpm * 0.9f));
            float torque = peakTorqueNm * (0.55f + 0.45f * torqueCurve) * ratio * Throttle;
            float driveForce = torque * 0.88f / 0.52f;
            if (Transmission.gear == 0) driveForce = -driveForce;
            if (speed < maxSpeedKph || driveForce < 0f)
                body.AddForce(transform.forward * driveForce, ForceMode.Force);
            float drag = aerodynamicDrag * body.velocity.sqrMagnitude + rollingResistance;
            body.AddForce(-body.velocity.normalized * drag, ForceMode.Force);
            float brakeFade = Mathf.Lerp(1f, 0.45f, Mathf.InverseLerp(150f, 350f, engineTemperature));
            body.AddForce(-transform.forward * (brake * serviceBrakeForce * brakeFade +
                Retarder * engineBrakeForce), ForceMode.Force);
            ApplySteering(speed, dt);
            Rpm = Mathf.Clamp(idleRpm + Throttle * (maxRpm - idleRpm) * Mathf.Clamp(ratio, 0.4f, 3.8f), idleRpm, maxRpm);
            engineTemperature = Mathf.MoveTowards(engineTemperature, 90f + Throttle * 28f, dt * 0.15f);
            GameEvents.RaiseSpeed(SpeedKph);
        }

        private void ApplySuspension()
        {
            if (wheels == null || wheels.Length == 0) return;
            float[] forces = new float[wheels.Length];
            for (int i = 0; i < wheels.Length; i++)
            {
                WheelPoint wheel = wheels[i];
                if (!wheel) continue;
                Vector3 origin = wheel.transform.position;
                float rayLength = wheel.restLength + wheel.radius;
                if (Physics.Raycast(origin, -transform.up, out RaycastHit hit, rayLength))
                {
                    float compression = Mathf.Clamp01((rayLength - hit.distance) / wheel.restLength);
                    float velocity = Vector3.Dot(body.GetPointVelocity(origin), transform.up);
                    forces[i] = Mathf.Max(0f, compression * wheel.springRate - velocity * wheel.damperRate);
                    body.AddForceAtPosition(transform.up * forces[i], origin, ForceMode.Force);
                    wheel.compression = compression;
                }
            }
            if (wheels.Length >= 4)
            {
                ApplyAntiRoll(0, 1, forces);
                ApplyAntiRoll(2, 3, forces);
            }
        }

        private void ApplyAntiRoll(int a, int b, float[] forces)
        {
            if (!wheels[a] || !wheels[b]) return;
            float anti = (wheels[a].compression - wheels[b].compression) * antiRollRate;
            body.AddForceAtPosition(transform.up * -anti, wheels[a].transform.position);
            body.AddForceAtPosition(transform.up * anti, wheels[b].transform.position);
        }

        private void ApplySteering(float speed, float dt)
        {
            float assist = Mathf.Lerp(1f, steeringAssistAtSpeed, Mathf.InverseLerp(15f, 100f, speed));
            float angle = Steering * maxSteerAngle * assist;
            foreach (WheelPoint wheel in wheels)
                if (wheel && wheel.steering)
                    wheel.transform.localRotation = Quaternion.Slerp(wheel.transform.localRotation,
                        Quaternion.Euler(0f, angle, 0f), dt * 5f);
        }

        public void SetEngine(bool running)
        {
            EngineRunning = running;
            GameEvents.RaiseEngineState(running);
        }

        public void SetPassengerLoad(int passengers, float luggageKg)
        {
            body.mass = vehicleMass + Mathf.Clamp(passengers, 0, 60) * 75f + Mathf.Max(0f, luggageKg);
        }
    }
}
