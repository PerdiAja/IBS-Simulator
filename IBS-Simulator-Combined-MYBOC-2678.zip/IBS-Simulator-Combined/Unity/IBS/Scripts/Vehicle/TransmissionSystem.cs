using UnityEngine;
namespace IBS.Vehicle
{
    /// <summary>Automatic or manual gearbox with configurable ratios.</summary>
    [System.Serializable]
    public sealed class TransmissionSystem
    {
        public bool automatic = true;
        public int gear = 1;
        public float finalDrive = 4.1f;
        public float[] ratios = { 3.8f, 2.4f, 1.6f, 1.1f, 0.85f, 0.68f };
        public float reverseRatio = -3.5f;
        public float ShiftRatio => gear == 0 ? reverseRatio : gear < 0 ? 0f :
            (gear <= ratios.Length ? ratios[gear - 1] : ratios[ratios.Length - 1]) * finalDrive;

        public void SetGear(int requested)
        {
            gear = Mathf.Clamp(requested, 0, ratios.Length);
        }

        public void Tick(float rpm, float speedKph)
        {
            if (!automatic) return;
            if (gear == 0) gear = 1;
            if (rpm > 2300f && gear < ratios.Length) gear++;
            else if (rpm < 950f && gear > 1 && speedKph < 75f) gear--;
        }
    }
}
