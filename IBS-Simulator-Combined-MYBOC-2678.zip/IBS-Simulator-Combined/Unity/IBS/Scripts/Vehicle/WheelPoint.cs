using UnityEngine;
namespace IBS.Vehicle
{
    /// <summary>Defines a raycast suspension attachment point.</summary>
    public sealed class WheelPoint : MonoBehaviour
    {
        public float radius = 0.48f;
        public float restLength = 0.42f;
        public float springRate = 38000f;
        public float damperRate = 4500f;
        public bool steering;
        public bool driven = true;
        [HideInInspector] public float compression;
    }
}
