using UnityEngine;
namespace IBS.Vehicle
{
    /// <summary>Air reservoir, compressor, service brake and parking brake simulation.</summary>
    [System.Serializable]
    public sealed class AirBrakeSystem
    {
        [Range(0f, 12f)] public float pressureBar = 10f;
        public float cutInBar = 9f;
        public float cutOutBar = 12f;
        public float compressorRate = 0.8f;
        public float fullBrakeUseBar = 0.6f;
        public bool parkingBrake = true;
        public bool LowPressureWarning => pressureBar < 5f;
        public float BrakeAvailability => Mathf.Clamp01(pressureBar / 5f);

        public float Tick(float brakeInput, float deltaTime)
        {
            if (pressureBar < cutOutBar) pressureBar = Mathf.Min(cutOutBar, pressureBar + compressorRate * deltaTime);
            pressureBar = Mathf.Max(0f, pressureBar - Mathf.Clamp01(brakeInput) * fullBrakeUseBar * deltaTime);
            return Mathf.Clamp01(brakeInput) * BrakeAvailability;
        }

        public void SetParkingBrake(bool enabled) => parkingBrake = enabled;
    }
}
