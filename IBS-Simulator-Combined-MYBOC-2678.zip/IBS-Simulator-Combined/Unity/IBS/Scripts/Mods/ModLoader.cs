using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using UnityEngine;
namespace IBS.Mods
{
    /// <summary>Safely validates IBS ZIP packages and extracts only safe data files.</summary>
    public sealed class ModLoader : MonoBehaviour
    {
        [SerializeField] private long maxPackageBytes = 150 * 1024 * 1024;
        [SerializeField] private string modFolderName = "Mods";
        public string ModRoot => Path.Combine(Application.persistentDataPath, modFolderName);
        private void Awake() { Directory.CreateDirectory(ModRoot); }
        public bool InstallPackage(string zipPath, out string message)
        {
            message = string.Empty;
            try
            {
                var info = new FileInfo(zipPath);
                if (!info.Exists || info.Length > maxPackageBytes) { message = "Paket tidak ditemukan atau terlalu besar."; return false; }
                using (ZipArchive archive = ZipFile.OpenRead(zipPath))
                {
                    bool hasManifest = false;
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        string normalized = entry.FullName.Replace('\\', '/');
                        if (Path.IsPathRooted(normalized) || normalized.Split('/').Contains(".."))
                        { message = "Paket ditolak: jalur file tidak aman."; return false; }
                        if (normalized == "manifest.json") hasManifest = true;
                    }
                    if (!hasManifest) { message = "manifest.json tidak ditemukan."; return false; }
                    string destination = Path.Combine(ModRoot, Path.GetFileNameWithoutExtension(zipPath));
                    Directory.CreateDirectory(destination);
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        string normalized = entry.FullName.Replace('\\', '/');
                        string target = Path.GetFullPath(Path.Combine(destination, normalized));
                        string basePath = Path.GetFullPath(destination) + Path.DirectorySeparatorChar;
                        if (!target.StartsWith(basePath, StringComparison.Ordinal)) { message = "Path traversal ditolak."; return false; }
                        if (normalized.EndsWith("/")) Directory.CreateDirectory(target);
                        else { Directory.CreateDirectory(Path.GetDirectoryName(target)); entry.ExtractToFile(target, true); }
                    }
                }
                message = "Mod berhasil dipasang."; return true;
            }
            catch (Exception e) { message = "Gagal memasang mod: " + e.Message; return false; }
        }
    }
}
