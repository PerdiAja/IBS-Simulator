using System;
namespace IBS.Mods
{
    /// <summary>Metadata contract for data-only IBS community packages.</summary>
    [Serializable]
    public sealed class ModManifest
    {
        public string id, name, author, version, type, apiVersion, entry;
    }
}
