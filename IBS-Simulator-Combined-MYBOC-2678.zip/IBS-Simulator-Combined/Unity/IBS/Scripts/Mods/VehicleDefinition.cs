using System;
namespace IBS.Mods
{
    /// <summary>Serializable vehicle tuning data supplied by a validated mod package.</summary>
    [Serializable]
    public sealed class VehicleDefinition
    {
        public string id, displayName;
        public float wheelbase = 6.2f, mass = 12500f, wheelRadius = 0.48f, maxTorqueNm = 900f;
        public float[] gearRatios = { 3.8f, 2.4f, 1.6f, 1.1f, 0.85f, 0.68f };
        public int passengerCapacity = 45;
    }
}
