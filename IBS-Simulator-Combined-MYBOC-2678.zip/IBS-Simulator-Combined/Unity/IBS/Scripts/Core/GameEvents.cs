using System;
using UnityEngine;

namespace IBS.Core
{
    /// <summary>Typed runtime event hub used to reduce direct module coupling.</summary>
    public static class GameEvents
    {
        public static event Action<float> SpeedChanged;
        public static event Action<string> Notification;
        public static event Action<int> MoneyChanged;
        public static event Action<bool> EngineStateChanged;

        public static void RaiseSpeed(float value) => SpeedChanged?.Invoke(value);
        public static void RaiseNotification(string message) => Notification?.Invoke(message);
        public static void RaiseMoney(int value) => MoneyChanged?.Invoke(value);
        public static void RaiseEngineState(bool running) => EngineStateChanged?.Invoke(running);
    }
}
