using UnityEngine;
using IBS.Vehicle;
namespace IBS.Input
{
    /// <summary>Receives mobile UI, keyboard and gamepad values and routes them to the bus.</summary>
    public sealed class BusInputRouter : MonoBehaviour
    {
        [SerializeField] private BusController bus;
        [SerializeField, Range(0f, 1f)] private float smoothing = 0.18f;
        [SerializeField] private bool keyboardEnabled = true;
        private float throttle, brake, steering;

        private void Update()
        {
            float targetThrottle = 0f, targetBrake = 0f, targetSteer = 0f;
            if (keyboardEnabled)
            {
                targetThrottle = UnityEngine.Input.GetKey(KeyCode.W) || UnityEngine.Input.GetKey(KeyCode.UpArrow) ? 1f : 0f;
                targetBrake = UnityEngine.Input.GetKey(KeyCode.S) || UnityEngine.Input.GetKey(KeyCode.DownArrow) ? 1f : 0f;
                targetSteer = (UnityEngine.Input.GetKey(KeyCode.D) ? 1f : 0f) - (UnityEngine.Input.GetKey(KeyCode.A) ? 1f : 0f);
            }
            throttle = Mathf.Lerp(throttle, targetThrottle, 1f - smoothing);
            brake = Mathf.Lerp(brake, targetBrake, 1f - smoothing);
            steering = Mathf.Lerp(steering, targetSteer, 1f - smoothing);
            if (bus)
            {
                bus.Throttle = throttle;
                bus.Brake = brake;
                bus.Steering = steering;
            }
        }

        public void SetThrottle(float value) { if (bus) bus.Throttle = Mathf.Clamp01(value); }
        public void SetBrake(float value) { if (bus) bus.Brake = Mathf.Clamp01(value); }
        public void SetSteering(float value) { if (bus) bus.Steering = Mathf.Clamp(value, -1f, 1f); }
        public void SetRetarder(float value) { if (bus) bus.Retarder = Mathf.Clamp01(value); }
        public void SetParkingBrake(bool value) { if (bus) bus.AirBrakes.SetParkingBrake(value); }
        public void SetGear(int gear) { if (bus) bus.Transmission.SetGear(gear); }
    }
}
