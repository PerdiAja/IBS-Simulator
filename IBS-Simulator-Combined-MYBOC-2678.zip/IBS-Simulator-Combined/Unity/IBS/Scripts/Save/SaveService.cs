using System;
using System.IO;
using UnityEngine;
namespace IBS.Save
{
    /// <summary>Stores versioned local profile data in persistent storage.</summary>
    public sealed class SaveService : MonoBehaviour
    {
        [Serializable] public sealed class Profile { public int version = 1; public string playerName = "Pengemudi"; public int money = 25000000; public int level = 1; }
        private string SavePath => Path.Combine(Application.persistentDataPath, "ibs-profile.json");
        public Profile Current { get; private set; }
        private void Awake() { Load(); }
        public void Load()
        {
            if (File.Exists(SavePath))
            {
                try { Current = JsonUtility.FromJson<Profile>(File.ReadAllText(SavePath)); }
                catch (Exception e) { Debug.LogWarning("Save IBS rusak, membuat profil baru: " + e.Message); }
            }
            if (Current == null) Current = new Profile();
        }
        public void Save()
        {
            string temp = SavePath + ".tmp";
            File.WriteAllText(temp, JsonUtility.ToJson(Current, true));
            if (File.Exists(SavePath)) File.Delete(SavePath);
            File.Move(temp, SavePath);
        }
        public void ResetProfile() { Current = new Profile(); Save(); }
    }
}
