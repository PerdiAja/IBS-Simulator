using System.Collections.Generic;
using UnityEngine;
namespace IBS.Passenger
{
    /// <summary>Tracks active passenger agents and reports current occupancy.</summary>
    public sealed class PassengerManager : MonoBehaviour
    {
        [SerializeField] private int capacity = 45;
        private readonly List<PassengerAgent> passengers = new List<PassengerAgent>();
        public int Count => passengers.Count;
        public int AvailableSeats => Mathf.Max(0, capacity - Count);
        public void Register(PassengerAgent passenger)
        {
            if (passenger && !passengers.Contains(passenger) && passengers.Count < capacity) passengers.Add(passenger);
        }
        public void Unregister(PassengerAgent passenger) { if (passenger) passengers.Remove(passenger); }
        public void RemoveMissing()
        {
            for (int i = passengers.Count - 1; i >= 0; i--)
                if (!passengers[i]) passengers.RemoveAt(i);
        }
    }
}
