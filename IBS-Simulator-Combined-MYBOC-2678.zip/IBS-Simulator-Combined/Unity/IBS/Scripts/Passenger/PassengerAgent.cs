using UnityEngine;
using UnityEngine.AI;
namespace IBS.Passenger
{
    /// <summary>Simple passenger boarding, riding and alighting state machine.</summary>
    [RequireComponent(typeof(NavMeshAgent))]
    public sealed class PassengerAgent : MonoBehaviour
    {
        public enum State { Waiting, Boarding, Riding, Alighting }
        [SerializeField] private Transform destination;
        [SerializeField] private float patienceSeconds = 90f;
        public State CurrentState { get; private set; } = State.Waiting;
        private NavMeshAgent agent;
        private float patience;
        private void Awake() { agent = GetComponent<NavMeshAgent>(); patience = patienceSeconds; }
        private void Update()
        {
            if (CurrentState == State.Waiting) patience = Mathf.Max(0f, patience - Time.deltaTime);
            if (CurrentState == State.Boarding && (!agent.pathPending && agent.remainingDistance < 0.35f))
                CurrentState = State.Riding;
            if (CurrentState == State.Alighting && (!agent.pathPending && agent.remainingDistance < 0.35f))
                CurrentState = State.Waiting;
        }
        public void BeginBoarding(Transform seat)
        {
            if (!seat || !agent) return;
            destination = seat; agent.SetDestination(seat.position); CurrentState = State.Boarding;
        }
        public void BeginAlighting(Transform stop)
        {
            if (!stop || !agent) return;
            destination = stop; agent.SetDestination(stop.position); CurrentState = State.Alighting;
        }
        public bool HasLostPatience => patience <= 0f;
    }
}
