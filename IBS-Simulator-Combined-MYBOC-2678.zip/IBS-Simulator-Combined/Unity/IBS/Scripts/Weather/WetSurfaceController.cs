using UnityEngine;
namespace IBS.Weather
{
    /// <summary>Publishes wet-road shader parameters globally.</summary>
    public sealed class WetSurfaceController : MonoBehaviour
    {
        [SerializeField, Range(0f, 1f)] private float wetness;
        [SerializeField] private WeatherManager weather;
        private static readonly int WetnessId = Shader.PropertyToID("_IBSWetness");
        private void Update()
        {
            if (weather) wetness = Mathf.MoveTowards(wetness,
                weather.Current == WeatherManager.Weather.Clear ? 0f : 0.65f, Time.deltaTime * 0.03f);
            Shader.SetGlobalFloat(WetnessId, wetness);
        }
    }
}
