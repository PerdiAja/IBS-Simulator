using UnityEngine;
namespace IBS.Weather
{
    /// <summary>Blends weather intensity over a configurable transition interval.</summary>
    public sealed class WeatherManager : MonoBehaviour
    {
        public enum Weather { Clear, Cloudy, Drizzle, Rain, HeavyRain, Storm, Fog }
        [SerializeField] private Weather current = Weather.Clear;
        [SerializeField] private ParticleSystem rainParticles;
        [SerializeField] private Light sun;
        [SerializeField] private float transitionSeconds = 60f;
        private float intensity, target;
        public Weather Current => current;
        private void Update()
        {
            intensity = Mathf.MoveTowards(intensity, target, Time.deltaTime / Mathf.Max(1f, transitionSeconds));
            if (rainParticles)
            {
                var emission = rainParticles.emission;
                emission.rateOverTime = intensity * 900f;
                if (intensity > 0.01f && !rainParticles.isPlaying) rainParticles.Play();
                if (intensity <= 0.01f && rainParticles.isPlaying) rainParticles.Stop();
            }
            if (sun) sun.intensity = Mathf.Lerp(1.15f, 0.55f, intensity);
        }
        public void SetWeather(Weather weather)
        {
            current = weather;
            target = weather == Weather.Drizzle ? 0.2f : weather == Weather.Rain ? 0.55f :
                weather == Weather.HeavyRain ? 0.85f : weather == Weather.Storm ? 1f : 0f;
            if (weather == Weather.Fog) RenderSettings.fog = true;
            else RenderSettings.fog = false;
            RenderSettings.fogDensity = weather == Weather.Fog ? 0.035f : 0.008f;
        }
    }
}
