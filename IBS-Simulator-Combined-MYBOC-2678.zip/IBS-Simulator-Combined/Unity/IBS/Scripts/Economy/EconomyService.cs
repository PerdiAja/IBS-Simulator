using UnityEngine;
using IBS.Core;
namespace IBS.Economy
{
    /// <summary>Manages player money and simple income/expense transactions.</summary>
    public sealed class EconomyService : MonoBehaviour
    {
        [SerializeField] private int startingMoney = 25000000;
        public int Balance { get; private set; }
        private void Awake() { Balance = PlayerPrefs.GetInt("IBS_Money", startingMoney); }
        public bool Spend(int amount)
        {
            if (amount < 0 || Balance < amount) return false;
            Balance -= amount; Persist(); return true;
        }
        public void Earn(int amount)
        {
            if (amount <= 0) return;
            Balance = Mathf.Min(int.MaxValue - amount, Balance) + amount; Persist();
        }
        private void Persist() { PlayerPrefs.SetInt("IBS_Money", Balance); PlayerPrefs.Save(); GameEvents.RaiseMoney(Balance); }
    }
}
