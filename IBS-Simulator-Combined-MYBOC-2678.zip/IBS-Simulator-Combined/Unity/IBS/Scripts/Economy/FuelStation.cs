using UnityEngine;
namespace IBS.Economy
{
    /// <summary>Refuels the active vehicle and charges the configured price per litre.</summary>
    public sealed class FuelStation : MonoBehaviour
    {
        [SerializeField] private float tankCapacityLitres = 300f;
        [SerializeField] private float fuelLitres = 120f;
        [SerializeField] private int pricePerLitre = 6800;
        public float FuelLitres => fuelLitres;
        public bool Refuel(float litres, EconomyService economy)
        {
            if (!economy || litres <= 0f) return false;
            float amount = Mathf.Min(litres, tankCapacityLitres - fuelLitres);
            int cost = Mathf.CeilToInt(amount * pricePerLitre);
            if (amount <= 0f || !economy.Spend(cost)) return false;
            fuelLitres += amount; return true;
        }
        public void Consume(float litres) => fuelLitres = Mathf.Max(0f, fuelLitres - Mathf.Max(0f, litres));
    }
}
