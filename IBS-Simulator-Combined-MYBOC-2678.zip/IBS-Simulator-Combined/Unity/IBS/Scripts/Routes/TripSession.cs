using UnityEngine;
namespace IBS.Routes
{
    /// <summary>Tracks a single Narik or charter trip, schedule and passenger satisfaction.</summary>
    public sealed class TripSession : MonoBehaviour
    {
        public enum TripType { Narik, Pariwisata }
        [SerializeField] private TripType type;
        [SerializeField] private float scheduledDurationMinutes = 60f;
        [SerializeField] private int baseFare = 250000;
        public float ElapsedMinutes { get; private set; }
        public bool IsRunning { get; private set; }
        public void Begin(TripType tripType, float durationMinutes, int fare)
        {
            type = tripType; scheduledDurationMinutes = Mathf.Max(1f, durationMinutes);
            baseFare = Mathf.Max(0, fare); ElapsedMinutes = 0f; IsRunning = true;
        }
        private void Update() { if (IsRunning) ElapsedMinutes += Time.deltaTime / 60f; }
        public int Complete()
        {
            IsRunning = false;
            float late = Mathf.Max(0f, ElapsedMinutes - scheduledDurationMinutes);
            return Mathf.RoundToInt(baseFare * Mathf.Clamp01(1f - late / scheduledDurationMinutes * 0.5f));
        }
    }
}
