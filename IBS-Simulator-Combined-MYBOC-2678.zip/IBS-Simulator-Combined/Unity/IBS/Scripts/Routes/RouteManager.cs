using System.Collections.Generic;
using UnityEngine;
namespace IBS.Routes
{
    /// <summary>Stores route stops and exposes the next destination.</summary>
    public sealed class RouteManager : MonoBehaviour
    {
        [SerializeField] private List<Transform> stops = new List<Transform>();
        public int CurrentStopIndex { get; private set; }
        public Transform CurrentStop => stops.Count == 0 ? null : stops[Mathf.Clamp(CurrentStopIndex, 0, stops.Count - 1)];
        public void SetStops(IEnumerable<Transform> routeStops) { stops = new List<Transform>(routeStops); CurrentStopIndex = 0; }
        public bool Advance()
        {
            if (CurrentStopIndex + 1 >= stops.Count) return false;
            CurrentStopIndex++; return true;
        }
        public void ResetRoute() => CurrentStopIndex = 0;
    }
}
