# IBS Simulator — Combined Source Workspace

Satu workspace yang mengumpulkan tiga bagian proyek:

- `Flutter/` — aplikasi Android utama/launcher (berisi `pubspec.yaml`, ikon launcher, splash, menu, dan pemeriksaan koneksi server).
- `Unity/` — proyek game 3D (Unity 6, scripts kendaraan, AI/traffic, penumpang, cuaca, rute, save, dan networking).
- `Server/` — backend Node.js + Express + Socket.IO + SQLite.

## Struktur dan hubungan

Flutter adalah shell aplikasi Android. Unity adalah mesin game 3D. Server menangani API, akun, penyimpanan, dan room. Ketiganya kini berada dalam satu folder proyek agar mudah dikelola, tetapi **Unity belum tertanam ke APK Flutter**.

## Menjalankan bagian-bagian

### Flutter
```bash
cd Flutter
flutter pub get
flutter run
```

### Server
```bash
cd Server
cp .env.example .env
# Isi JWT_SECRET yang kuat di .env
npm install
npm start
```

### Unity
Buka folder `Unity/` melalui Unity Hub menggunakan Unity 6 dengan Android Build Support (SDK, NDK, OpenJDK).

## Menggabungkan Unity ke APK Flutter (langkah yang masih diperlukan)

1. Buka `Unity/` pada Unity Editor.
2. Pastikan Android Build Support terpasang dan target Android aktif.
3. Pilih Build Profiles > Android dan aktifkan opsi ekspor proyek sebagai Gradle/Android Library sesuai versi Unity Editor.
4. Build/Export Unity as a Library. Hasil ekspor harus berisi modul `unityLibrary` asli.
5. Salin modul `unityLibrary` hasil ekspor ke `Flutter/android/unityLibrary` (gantikan README placeholder ini).
6. Tambahkan modul dan dependensi Gradle yang dihasilkan Unity ke `Flutter/android/settings.gradle` dan `Flutter/android/build.gradle`, mengikuti panduan integrasi yang sesuai dengan versi Unity tersebut.
7. Implementasikan Android Activity/Fragment atau platform channel untuk membuat, menampilkan, pause/resume, dan menutup `UnityPlayer`. Tombol Mulai Bermain di Flutter perlu dihubungkan ke bridge native ini.
8. Build dan uji di perangkat Android fisik: masuk game, tombol kembali, pause/resume, rotasi, RAM, suhu, dan stabilitas.

**Penting:** Tidak ada modul `unityLibrary` tiruan dalam paket ini. Unity harus diekspor dari Unity Editor agar file Gradle, AAR, manifest, dan resource cocok dengan versi editor yang benar. Karena proses ekspor dan build Android memerlukan Unity Editor + Android SDK/NDK, integrasi final belum bisa diklaim selesai dari ZIP sumber ini.

## Status

Ini adalah workspace source/starter, bukan APK game siap rilis. Model bus 3D final, map lengkap, prefab/scene final, animasi, konten, serta integrasi Unity-Flutter masih memerlukan pengerjaan dan pengujian. Lihat `Unity/Docs/ROADMAP.md` dan `Unity/Docs/FLUTTER_UNITY_INTEGRATION.md`.

## Server hosting

Konfigurasi awal domain/port yang diberikan tersedia di `Server/DEPLOYMENT-MYBOC.md`. Flutter sudah diarahkan ke `https://garzy-official-store.myboc.my.id:2678`. Pastikan port tersebut benar-benar melayani HTTPS; jika TLS hanya melalui reverse proxy port 443, hilangkan `:2678` dari URL aplikasi.
