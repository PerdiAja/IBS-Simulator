const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('./db');

function issueToken(user) {
  return jwt.sign({ sub: user.id, username: user.username }, process.env.JWT_SECRET, { expiresIn: '30d' });
}
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  try {
    if (!token) throw new Error('missing token');
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ ok: false, error: 'Sesi tidak valid. Silakan login kembali.' });
  }
}
function register(username, password) {
  const hash = bcrypt.hashSync(password, 12);
  const result = db.prepare('INSERT INTO users(username,password_hash) VALUES(?,?)').run(username, hash);
  return { id: Number(result.lastInsertRowid), username };
}
function login(username, password) {
  const user = db.prepare('SELECT id,username,password_hash FROM users WHERE username=?').get(username);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return null;
  return { id: user.id, username: user.username };
}
module.exports = { issueToken, requireAuth, register, login };
