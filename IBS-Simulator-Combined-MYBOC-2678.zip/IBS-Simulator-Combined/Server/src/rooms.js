const crypto = require('node:crypto');
const rooms = new Map();
const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function makeCode() {
  let code;
  do { code = Array.from({ length: 6 }, () => alphabet[crypto.randomInt(alphabet.length)]).join(''); }
  while (rooms.has(code));
  return code;
}
function createRoom({ hostId, hostName, map = 'Kutoarjo', mode = 'Convoy Bebas', maxPlayers = 8, isPrivate = false }) {
  const code = makeCode();
  const room = { code, hostId, hostName, map, mode, maxPlayers: Math.min(16, Math.max(2, Number(maxPlayers) || 8)),
    isPrivate: Boolean(isPrivate), players: new Map(), createdAt: Date.now() };
  rooms.set(code, room);
  return room;
}
function publicRoom(room) {
  return { code: room.code, hostName: room.hostName, map: room.map, mode: room.mode,
    players: room.players.size, maxPlayers: room.maxPlayers, isPrivate: room.isPrivate };
}
function removeRoom(code) { rooms.delete(code); }
function pruneRooms() {
  const cutoff = Date.now() - 6 * 60 * 60 * 1000;
  for (const [code, room] of rooms) if (room.createdAt < cutoff || room.players.size === 0) rooms.delete(code);
}
setInterval(pruneRooms, 60000).unref();
module.exports = { rooms, createRoom, publicRoom, removeRoom };
