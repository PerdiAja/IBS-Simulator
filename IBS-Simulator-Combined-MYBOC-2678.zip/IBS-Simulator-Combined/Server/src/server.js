require('dotenv').config();
const http = require('node:http');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');
const db = require('./db');
const auth = require('./auth');
const { rooms, createRoom, publicRoom, removeRoom } = require('./rooms');

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error('JWT_SECRET wajib diisi minimal 32 karakter pada file .env');
  process.exit(1);
}
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CORS_ORIGIN || '*', methods: ['GET','POST'] } });
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '2mb' }));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'IBS Simulator Server', time: new Date().toISOString() }));
app.post('/api/auth/register', (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!/^[a-z0-9_]{3,20}$/.test(username) || password.length < 8)
    return res.status(400).json({ ok: false, error: 'Username 3-20 karakter (huruf/angka/_) dan password minimal 8 karakter.' });
  try {
    const user = auth.register(username, password);
    return res.status(201).json({ ok: true, token: auth.issueToken(user), user });
  } catch (error) {
    if (String(error.code).includes('SQLITE_CONSTRAINT')) return res.status(409).json({ ok: false, error: 'Username sudah digunakan.' });
    return res.status(500).json({ ok: false, error: 'Gagal membuat akun.' });
  }
});
app.post('/api/auth/login', (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const user = auth.login(username, String(req.body.password || ''));
  if (!user) return res.status(401).json({ ok: false, error: 'Username atau password salah.' });
  res.json({ ok: true, token: auth.issueToken(user), user });
});
app.get('/api/me', auth.requireAuth, (req, res) => res.json({ ok: true, user: { id: req.user.sub, username: req.user.username } }));
app.get('/api/save', auth.requireAuth, (req, res) => {
  const row = db.prepare('SELECT payload,updated_at FROM saves WHERE user_id=?').get(req.user.sub);
  res.json({ ok: true, save: row ? JSON.parse(row.payload) : null, updatedAt: row?.updated_at || null });
});
app.put('/api/save', auth.requireAuth, (req, res) => {
  const payload = JSON.stringify(req.body.save ?? {});
  if (Buffer.byteLength(payload) > 1024 * 1024) return res.status(413).json({ ok: false, error: 'Data save melebihi 1 MB.' });
  db.prepare(`INSERT INTO saves(user_id,payload,updated_at) VALUES(?,?,CURRENT_TIMESTAMP)
    ON CONFLICT(user_id) DO UPDATE SET payload=excluded.payload,updated_at=CURRENT_TIMESTAMP`).run(req.user.sub, payload);
  res.json({ ok: true });
});
app.post('/api/rooms', auth.requireAuth, (req, res) => {
  if (rooms.size >= Number(process.env.MAX_ROOMS || 200)) return res.status(503).json({ ok: false, error: 'Server room penuh.' });
  const room = createRoom({ hostId: req.user.sub, hostName: req.user.username, ...req.body });
  db.prepare('INSERT INTO room_history(room_code,host_user_id) VALUES(?,?)').run(room.code, req.user.sub);
  res.status(201).json({ ok: true, room: publicRoom(room) });
});
app.get('/api/rooms', (_req, res) => res.json({ ok: true, rooms: [...rooms.values()].filter(r => !r.isPrivate).map(publicRoom) }));
app.get('/api/rooms/:code', (req, res) => {
  const room = rooms.get(String(req.params.code).toUpperCase());
  if (!room) return res.status(404).json({ ok: false, error: 'Room tidak ditemukan.' });
  res.json({ ok: true, room: publicRoom(room) });
});
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ ok: false, error: 'Terjadi kesalahan server.' });
});

io.use((socket, next) => {
  try {
    const token = String(socket.handshake.auth?.token || '');
    socket.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch { next(new Error('AUTH_REQUIRED')); }
});
io.on('connection', socket => {
  socket.on('room:join', ({ code } = {}, callback = () => {}) => {
    const room = rooms.get(String(code || '').toUpperCase());
    if (!room) return callback({ ok: false, error: 'Room tidak ditemukan.' });
    if (room.players.size >= room.maxPlayers) return callback({ ok: false, error: 'Room penuh.' });
    if (room.isPrivate && room.hostId !== socket.user.sub) return callback({ ok: false, error: 'Room privat.' });
    room.players.set(socket.id, { userId: socket.user.sub, username: socket.user.username });
    socket.join(room.code);
    io.to(room.code).emit('room:players', [...room.players.values()]);
    callback({ ok: true, room: publicRoom(room) });
  });
  socket.on('bus:state', (state = {}) => {
    const room = [...rooms.values()].find(r => r.players.has(socket.id));
    if (!room) return;
    const pos = state.position || {};
    const speed = Number(state.speedKph || 0);
    if (![pos.x, pos.y, pos.z, speed].every(Number.isFinite) || speed < 0 || speed > 160) return;
    const safeState = { userId: socket.user.sub, username: socket.user.username,
      position: { x: pos.x, y: pos.y, z: pos.z }, rotation: state.rotation || { x: 0, y: 0, z: 0, w: 1 },
      speedKph: speed, signals: state.signals || {}, sentAt: Date.now() };
    socket.to(room.code).volatile.emit('bus:state', safeState);
  });
  socket.on('disconnect', () => {
    for (const [code, room] of rooms) {
      if (room.players.delete(socket.id)) {
        io.to(code).emit('room:players', [...room.players.values()]);
        if (room.players.size === 0) removeRoom(code);
      }
    }
  });
});

const port = Number(process.env.PORT || 2678);
const host = process.env.HOST || '0.0.0.0';
server.listen(port, host, () => console.log(`IBS server aktif di http://${host}:${port}`));
