# Konfigurasi deployment IBS Simulator

Domain yang diberikan: `garzy-official-store.myboc.my.id`
Port aplikasi: `2678`
URL yang dipakai aplikasi Flutter: `https://garzy-official-store.myboc.my.id:2678`

## Environment variables
- `HOST=0.0.0.0`
- `PORT=2678`
- `JWT_SECRET`: ganti dengan rahasia acak minimal 32 karakter. Jangan commit nilai rahasia ke GitHub.
- `CORS_ORIGIN=*` (ubah ke origin aplikasi/web yang dibutuhkan jika pembatasan CORS diterapkan).
- `DB_PATH=./data/ibs.sqlite`

Pastikan panel hosting mengarahkan port 2678 ke proses Node.js dan TLS/HTTPS memang aktif untuk port tersebut. Jika HTTPS hanya tersedia pada port 443 melalui reverse proxy, gunakan `https://garzy-official-store.myboc.my.id` tanpa `:2678` dan atur proxy ke port internal 2678.

Tes setelah server berjalan: buka `https://garzy-official-store.myboc.my.id:2678/health`. Hasil yang diharapkan berupa JSON dengan `ok: true`. Jika gagal, periksa binding port, firewall, konfigurasi proxy, sertifikat TLS, dan log hosting.
